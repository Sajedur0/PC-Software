Author: BlueLife , Velociraptor
www.sordum.org

---------------- Windows Settings Blocker v1.2 ---------------------
(Saturday, July 16, 2022)

Changelog:

1. [Fixed] - Information pop ups overlap in Windows 11
2. [Fixed] - Settings app sometimes won't close in Windows 11
3. [Fixed] - Software name only highlights Windows 10
4. [Fixed] - Software GUI and Font is too small
5. [Added] - Improvements in coding


---------------- Win10 Settings Blocker v1.1 ---------------------
(November 10, 2018)

Changelog:

1. [Added] - Hide specified control panel items
2. [Added] - Export - Import Feature
3. [Added] - Some code improvements

---------------- Win10 Settings Blocker v1.0 ---------------------
(October 26, 2018)

To stop users from changing settings in Windows 10 you can lock down individual Settings panes and 
Control Panel items with Win10 Settings Blocker Application. It is a Portable freeware