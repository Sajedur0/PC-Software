Author: BlueLife , Velociraptor
www.sordum.org

[010101010101010101]--SwitchPowerScheme v1.3 --[010101010101010101]

Friday, 11 July 2021
------------
Changelog:
01. FIXED - The translation error in the export - import option
02. ADDED - You can see active power scheme when mouse hovers over tray icon
03. ADDED - Ability to choose location of current program for import and export
04. ADDED - Some cede Improvements


[010101010101010101]--SwitchPowerScheme v1.2 --[010101010101010101]

Sunday, 19 July 2020
------------
Changelog:
01. FIXED - On GUI after 28 characters the text is faded away (New GUI design)
02. ADDED - Shift key option for the context menu
03. ADDED - Option to work from system tray
04. ADDED - Import- Export Power plan options
05. ADDED - Autostart with windows startup , Hide minimize, Hide Window on startup , Always on top options
06. ADDED - Delete , Rename , Activate Power plan options
07. ADDED - Create Shortcut for any Power plan option
08. ADDED - Power Plan list option
09. ADDED - Reset Power Plans option
10. ADDED - Language support option

[010101010101010101]--SwitchPowerScheme v1.1 --[010101010101010101]

Saturday, July 4, 2020
-------------
Changelog:
1. FIXED - Program doesn't show user created power plans
2. ADDED - Power Options (GUI and Right click menu)
3. ADDED - x64 version


[010101010101010101]--SwitchPowerScheme v1.0 --[010101010101010101]

Saturday, December 31, 2016
-------------------------------
A small Portable Application to simplify Switching Power Plans via GUI or desktop context menu
