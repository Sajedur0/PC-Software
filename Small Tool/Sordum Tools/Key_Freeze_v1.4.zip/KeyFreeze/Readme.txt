Author: BlueLife ,Velociraptor
www.sordum.org



####################-- v1.4 what is new (27.02.2017) --####################

[Fixed] - When the position of the taskbar changes info popup doesn't appear
[Fixed] - CPU usage reduced
[Fixed] - Some Minor Bugs

####################-- v1.3 what is new (11.02.2015) --####################

complete new coded
[Added] - Keyboard and mouse Lock (together or separately)
[Added] - Lock - Unlock shortkey (default : Ctrl + Alt + F)
[Added] - User Lock (when kesy unlocked)
[Added] - Now Ctrl + Alt + Del unlock shortkey is optional
[Added] - After Lock the Mose allow Mouse movement option
[Added] - editable countdown timer ( 0-25 second , "0" = disabled)
[Added] - Lock the keys when system is idle option ( 0-60 minute , "0" = disabled)
[Added] - Lock on Startup is now optional
[Added] - information popup for Locking , Unlocking or Countdown
[Added] - Play sound option
[Added] - Tray menu for Locking , Unlocking or Countdown
[Added] - Hide Tray icon when keys are locked option
[Added] - Double click Tray icon to Lock or unlock keys option
[Added] - Language Options

####################-- v1.2 what is new (26.02.2013) --####################
- New design
- improved code stabilization
- Cancel locking option added
- Auto countdown added

####################-- v1.1 what is new ( 04.03.2012) --####################
- Explorer launch bar is activated unexpectedly - Fixed

####################-- v1.1 First release(19.02.2011) --####################
- You can easily block your Keyboard and mouse